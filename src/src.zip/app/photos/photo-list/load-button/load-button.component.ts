import { Component, OnInit, Input } from '@angular/core';

// PAGINACAO

@Component({
  selector: 'ap-load-button',
  templateUrl: './load-button.component.html',
  styleUrls: ['./load-button.component.css']
})
export class LoadButtonComponent implements OnInit {

  @Input() hasMore: boolean = false;
  constructor() { }

  ngOnInit() {
  }

}
