import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PhotoListComponent } from './photos/photo-list/photo-list.component';
import { PhotoFormComponent } from './photos/photo-form/photo-form.component';
import { NotFoundComponent } from './errors/not-found/not-found.component';
import { PhotoListResolver } from './photos/photo-list/photo-list.resolver';
import { SignInComponent } from './home/signin/signin.component';
import { SignUpComponent } from './home/signup/signup.component';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './core/auth/auth.guard';
import { LoginGuard } from './core/auth/login.guard';
import { PhotoDetailsComponent } from './photos/photo-details/photo-details.component';

const routes: Routes = [
    { 
      path: '',
      component: HomeComponent,
      canActivate: [LoginGuard],
      children: [
        { 
          path: '',
          component: SignInComponent,
          data: {
            title: 'Sign In'
          } 
       },
       { 
         path: 'signup',
         component: SignUpComponent,
         data: {
          title: 'Sign Up'
        } 
       },
      ]
    },
    { 
      path: 'user/:userName', 
      pathMatch: 'full',
      component: PhotoListComponent,
      resolve: {
          photos: PhotoListResolver
      },
      data: {
        title: 'Timeline'
      } 
    },
    { 
      path: 'p/add', 
      component: PhotoFormComponent,
      canActivate: [AuthGuard],
      data: {
        title: 'Photo Upload'
      } 
    },
    { 
      path: 'p/:photoId', 
      component: PhotoDetailsComponent,
      data: {
        title: 'Photo Detail'
      } 
    },
    { path: 'not-found', 
      component: NotFoundComponent,
      data: {
        title: 'Not Found'
      } 
    },
    { path: '**', 
      redirectTo: 'not-found' 
    }
];

@NgModule({
  // Para utilizar as rotas com HASHTAGS utilizar abaixo:
  // imports: [RouterModule.forRoot(routes, { useHash: true } )],
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
